import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import org.json.JSONException;
import org.json.JSONObject;

public class LRExporter {

	static String appName = null;
	static String environment = null;
	static String appCodeVersion = null;
	static String startTime = null;
	static String endTime = null;
	static final String FILE_RUNTIME_INFO = "RunInfo.txt";
	static ArrayList<String> FILE_TRANSACTION_INFO;
	static String FILE_OUTPUT_LOG_INFO;

	public static void main(String[] args) throws Exception {

		/* To Validate key command line arguments */

		if (args.length < 5 || args.length > 6) {
			System.out.println("Invlaid Command Line Arguments");
			System.out.println(
					"Usage : java -jar <AppName> <Environment> <CodeVersion> <JSON_Log_Path> <Output_Directory> [<OutputType=csv|keyvalue|json>]");
			System.out.println("Example : java -jar TestApp LTA v1.22 C:/temp/lrr/ c:/temp/logs/ OutputType=keyvalue");
		} else {

			FILE_TRANSACTION_INFO = getResultsFiles(args[3]);

			/* Read Key Inputs */
			setAppInfo(args[0], args[1], args[2]);

			/* Extract Runtime Information */
			readRunInfo(args[3]);

			/* Write Log File Headers */
			setLogFileName();

			/* Extract Transaction Information & Write To File */
			if (args.length <= 5) {
				for (String temp : FILE_TRANSACTION_INFO) {

					extractTransactionInformationKeyValue(temp, args[4]);
				}
			} else if (args[5].toLowerCase().contains("csv")) {
				for (String temp : FILE_TRANSACTION_INFO) {

					extractTransactionInformationCSV(temp, args[4]);
				}
			} else if (args[5].toLowerCase().contains("keyvalue")) {
				for (String temp : FILE_TRANSACTION_INFO) {
					extractTransactionInformationKeyValue(temp, args[4]);
				}
			}

			/* To Print Console outputs */
			printOutPuts();
		}
	}

	public static ArrayList<String> getResultsFiles(String path) {
		ArrayList<String> transactionFiles = new ArrayList<String>();
		File resultDirectory = new File(path);
		File[] files = resultDirectory.listFiles();
		for (File temp : files) {
			if (temp.getAbsolutePath().contains("gzl")) {
				transactionFiles.add(temp.getAbsolutePath());
			}
		}
		return transactionFiles;
	}

	public static void printOutPuts() {
		System.out.println("Appname : " + appName);
		System.out.println("AppCodeVersion : " + appCodeVersion);
		System.out.println("Environment : " + environment);
		System.out.println("Start Time : " + startTime);
		System.out.println("End Time : " + endTime);
	}

	public static void setLogFileName() {
		FILE_OUTPUT_LOG_INFO = "SL_" + appName + "_" + environment + "_" + appCodeVersion + "_" + startTime + ".log";
	}

	public static void setAppInfo(String app, String env, String code) {
		appName = app;
		environment = env;
		appCodeVersion = code;
	}

	public static void readRunInfo(String filePath) throws IOException {
		FileReader fileReader = new FileReader(new File(filePath + FILE_RUNTIME_INFO));
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		String line = bufferedReader.readLine();
		if (line != null) {
			line = removeSquareBrackets(line);
		}
		bufferedReader.close();
		fileReader.close();
		startTime = getStartTime(line);
		endTime = getEndTime(line);
	}

	public static void extractTransactionInformationCSV(String filePath, String destPath) throws Exception {

		if (!(new File(destPath).exists()))
			new File(destPath).mkdir();

		FileReader fileReader = new FileReader(new File(filePath));
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		String line;
		while ((line = bufferedReader.readLine()) != null) {
			if ((line = filterTransactionData(removeSquareBrackets(line))) != null) {
				WriteToLog(destPath, extractTransactionCSV(line));
			}
		}

		bufferedReader.close();
		fileReader.close();
		System.out.println("Saved logs to file : " + destPath + FILE_OUTPUT_LOG_INFO);

	}

	public static void extractTransactionInformationKeyValue(String filePath, String destPath) throws Exception {

		if (!(new File(destPath).exists()))
			new File(destPath).mkdir();

		FileReader fileReader = new FileReader(new File(filePath));
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		String line;
		while ((line = bufferedReader.readLine()) != null) {
			if ((line = filterTransactionData(removeSquareBrackets(line))) != null) {
				WriteToLog(destPath, extractTransactionKeyValue(line));
			}
		}

		bufferedReader.close();
		fileReader.close();
		System.out.println("Saved logs to file : " + destPath + FILE_OUTPUT_LOG_INFO);

	}

	public static String removeSquareBrackets(String input) {
		return input.replace("[", "").replace("]", "");
	}

	public static String getStartTime(String line) {
		JSONObject jsonObj = new JSONObject(line);
		// Date date = new
		// Date(Long.parseLong(jsonObj.getJSONObject("RunInfo").getString("Start_time")+"000"));
		return jsonObj.getJSONObject("RunInfo").getString("Start_time");

	}

	public static String getEndTime(String line) {
		JSONObject jsonObj = new JSONObject(line);
		// Date date = new
		// Date(Long.parseLong(jsonObj.getJSONObject("RunInfo").getString("Stop_time")+"000"));
		return jsonObj.getJSONObject("RunInfo").getString("Stop_time");

	}

	public static String filterTransactionData(String line) {

		if (line.contains("\"Transaction\"")) {
			return line;
		}

		return null;
	}

	public static String extractTransactionCSV(String line) {
		String temp = appName + "," + environment + "," + appCodeVersion + ",";
		JSONObject jsonObj = new JSONObject(line);
		temp = temp + jsonObj.getJSONObject("Transaction").getString("StartTime").replace(".", "").substring(0, 10)
				+ ",";
		temp = temp + jsonObj.getJSONObject("Transaction").getString("Name") + ",";
		temp = temp + jsonObj.getJSONObject("Transaction").getString("VuserGroup") + ",";
		double responseTime = Double.parseDouble(jsonObj.getJSONObject("Transaction").getString("EndTime"))
				- (Double.parseDouble(jsonObj.getJSONObject("Transaction").getString("StartTime"))
						+ Double.parseDouble(jsonObj.getJSONObject("Transaction").getString("WastedTime")));
		temp = temp + responseTime + ",";
		temp = temp + getTransactionStatus(jsonObj.getJSONObject("Transaction").getString("Status")) + ",";
		temp = temp + jsonObj.getJSONObject("Transaction").getString("VuserID") + ",";
		temp = temp + startTime + "," + endTime;
		return temp + System.lineSeparator();
	}

	public static String extractTransactionKeyValue(String line) {
		String temp = "App=" + appName + "," + "Env=" + environment + "," + "CodeVer=" + appCodeVersion + ",";
		JSONObject jsonObj = new JSONObject(line);
		temp = temp + "SampleTime="
				+ jsonObj.getJSONObject("Transaction").getString("StartTime").replace(".", "").substring(0, 10) + ",";
		temp = temp + "Transaction=" + jsonObj.getJSONObject("Transaction").getString("Name") + ",";
		temp = temp + "VuserGroup=" + jsonObj.getJSONObject("Transaction").getString("VuserGroup") + ",";
		double responseTime = Double.parseDouble(jsonObj.getJSONObject("Transaction").getString("EndTime"))
				- (Double.parseDouble(jsonObj.getJSONObject("Transaction").getString("StartTime"))
						+ Double.parseDouble(jsonObj.getJSONObject("Transaction").getString("WastedTime")));
		temp = temp + "RespTime=" + responseTime + ",";
		temp = temp + "Status=" + getTransactionStatus(jsonObj.getJSONObject("Transaction").getString("Status")) + ",";
		temp = temp + "VuserID=" + jsonObj.getJSONObject("Transaction").getString("VuserID") + ",";
		temp = temp + "TestStartTime=" + startTime + ",TestEndTime=" + endTime;
		return temp + System.lineSeparator();
	}

	public static String getTransactionStatus(String line) {
		if (line.equals("0")) {
			return "PASS";
		} else if (line.equals("1")) {
			return "FAIL";
		} else if (line.equals("2")) {
			return "STOPPED";
		} else {
			return "UNKNOWN";
		}
	}

	public static void WriteToLog(String filePath, String line) throws IOException {

		FileOutputStream fileStream = new FileOutputStream(new File(filePath + FILE_OUTPUT_LOG_INFO), true);
		fileStream.write(line.getBytes());
		fileStream.close();
	}

	public static void WriteLogHeaders(String filePath, String line) throws IOException {
		FileOutputStream fileStream = new FileOutputStream(new File(filePath + FILE_OUTPUT_LOG_INFO), true);
		fileStream.write(line.getBytes());
		fileStream.close();
	}

}
